import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import warnings
warnings.filterwarnings("ignore")

from utils.data_generator import generate_hr_data
from utils.preprocessing import preprocess_data
from utils.model import load_or_train_model, predict_attrition
from utils.sentiment import analyze_sentiment, get_department_morale
from utils.ai_interface import query_hr_ai

st.set_page_config(
    page_title="Smart HR Analytics",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=DM+Sans:wght@300;400;500;600&display=swap');
html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }
.main { background-color: #0d1117; }
.stApp { background: linear-gradient(135deg, #0d1117 0%, #161b22 100%); color: #e6edf3; }
h1, h2, h3 { font-family: 'Space Mono', monospace; color: #58a6ff; }
.metric-card { background: linear-gradient(135deg, #161b22, #21262d); border: 1px solid #30363d; border-radius: 12px; padding: 20px; text-align: center; transition: transform 0.2s; }
.metric-card:hover { transform: translateY(-2px); }
.metric-value { font-size: 2.2rem; font-weight: 700; font-family: 'Space Mono', monospace; color: #58a6ff; }
.metric-label { font-size: 0.85rem; color: #8b949e; text-transform: uppercase; letter-spacing: 0.1em; margin-top: 4px; }
.risk-high { color: #f85149 !important; }
.risk-medium { color: #e3b341 !important; }
.risk-low { color: #3fb950 !important; }
.ai-response-box { background: linear-gradient(135deg, #0d1117, #161b22); border: 1px solid #58a6ff44; border-left: 3px solid #58a6ff; border-radius: 8px; padding: 20px; margin-top: 12px; font-family: 'DM Sans', sans-serif; font-size: 0.95rem; line-height: 1.7; color: #c9d1d9; }
.section-header { font-family: 'Space Mono', monospace; font-size: 0.75rem; letter-spacing: 0.2em; text-transform: uppercase; color: #58a6ff; border-bottom: 1px solid #21262d; padding-bottom: 8px; margin-bottom: 16px; }
.stButton > button { background: linear-gradient(135deg, #1f6feb, #388bfd); color: white; border: none; border-radius: 8px; padding: 10px 24px; font-family: 'Space Mono', monospace; font-size: 0.85rem; letter-spacing: 0.05em; cursor: pointer; transition: all 0.2s; }
.stButton > button:hover { background: linear-gradient(135deg, #388bfd, #58a6ff); transform: translateY(-1px); box-shadow: 0 4px 15px #58a6ff33; }
[data-testid="stSidebar"] { background: #161b22; border-right: 1px solid #30363d; }
.stTextInput > div > input { background: #21262d; border: 1px solid #30363d; border-radius: 8px; color: #e6edf3; font-family: 'DM Sans', sans-serif; }
.stTextInput > div > input:focus { border-color: #58a6ff; box-shadow: 0 0 0 2px #58a6ff22; }
div[data-testid="metric-container"] { background: #161b22; border: 1px solid #30363d; border-radius: 10px; padding: 12px; }
</style>
""", unsafe_allow_html=True)


@st.cache_data
def load_data():
    return generate_hr_data(n=500, seed=42)

@st.cache_resource
def get_model(_df):
    X, y, preprocessor = preprocess_data(_df)
    model, cv_score, feat_importances = load_or_train_model(X, y, preprocessor)
    return model, cv_score, feat_importances, X, y, preprocessor

df_raw = load_data()
model, cv_score, feat_importances, X, y, preprocessor = get_model(df_raw)
df_raw = predict_attrition(df_raw, model, preprocessor)

with st.sidebar:
    st.markdown("## 🧠 HR Analytics")
    st.markdown("---")
    st.markdown("### Filters")
    dept_filter = st.multiselect(
        "Department",
        options=df_raw["Department"].unique().tolist(),
        default=df_raw["Department"].unique().tolist(),
    )
    risk_filter = st.multiselect(
        "Risk Level",
        options=["High", "Medium", "Low"],
        default=["High", "Medium", "Low"],
    )
    st.markdown("---")
    st.markdown("### Model Info")
    st.metric("CV Accuracy", f"{cv_score:.1%}")
    st.metric("Training Samples", len(df_raw))
    st.markdown("---")
    st.markdown("<small style='color:#8b949e'>Smart HR Analytics v1.0<br>Powered by Random Forest + GPT</small>", unsafe_allow_html=True)

df = df_raw[
    df_raw["Department"].isin(dept_filter) &
    df_raw["AttritionRisk"].isin(risk_filter)
].copy()

if df.empty:
    st.warning("No employees match the selected filters. Please adjust your sidebar filters.")
    st.stop()

st.markdown("# 🧠 Smart HR Analytics Dashboard")
st.markdown("<p style='color:#8b949e; margin-top:-10px; font-size:1rem;'>Employee Attrition Intelligence · Sentiment Analysis · AI Query Interface</p>", unsafe_allow_html=True)
st.markdown("---")

col1, col2, col3, col4, col5 = st.columns(5)
total = len(df)
high_risk = (df["AttritionRisk"] == "High").sum()
med_risk  = (df["AttritionRisk"] == "Medium").sum()
low_risk  = (df["AttritionRisk"] == "Low").sum()
avg_score = df["AttritionScore"].mean()

with col1: st.metric("Total Employees", total)
with col2: st.metric("🔴 High Risk", high_risk, delta=f"{high_risk/total:.0%} of workforce")
with col3: st.metric("🟡 Medium Risk", med_risk)
with col4: st.metric("🟢 Low Risk", low_risk)
with col5: st.metric("Avg Risk Score", f"{avg_score:.2f}")
st.markdown("---")

tab1, tab2, tab3, tab4 = st.tabs([
    "📊 Attrition Overview",
    "👥 Employee Risk Table",
    "💬 Sentiment Analysis",
    "🤖 AI Query Interface",
])

color_map = {"High": "#f85149", "Medium": "#e3b341", "Low": "#3fb950"}

with tab1:
    c1, c2 = st.columns(2)
    with c1:
        st.markdown('<p class="section-header">Risk Distribution by Department</p>', unsafe_allow_html=True)
        dept_risk = df.groupby(["Department", "AttritionRisk"]).size().reset_index(name="Count")
        fig = px.bar(dept_risk, x="Department", y="Count", color="AttritionRisk",
                     color_discrete_map=color_map, barmode="stack", template="plotly_dark")
        fig.update_layout(paper_bgcolor="#161b22", plot_bgcolor="#0d1117", font_color="#c9d1d9",
                          legend_title="Risk Level", margin=dict(l=10, r=10, t=10, b=10))
        st.plotly_chart(fig, use_container_width=True)

    with c2:
        st.markdown('<p class="section-header">Attrition Risk Score Distribution</p>', unsafe_allow_html=True)
        fig2 = px.histogram(df, x="AttritionScore", color="AttritionRisk",
                            color_discrete_map=color_map, nbins=30, template="plotly_dark")
        fig2.update_layout(paper_bgcolor="#161b22", plot_bgcolor="#0d1117", font_color="#c9d1d9",
                           margin=dict(l=10, r=10, t=10, b=10))
        st.plotly_chart(fig2, use_container_width=True)

    c3, c4 = st.columns(2)
    with c3:
        st.markdown('<p class="section-header">Salary vs Attrition Score</p>', unsafe_allow_html=True)
        fig3 = px.scatter(df, x="Salary", y="AttritionScore", color="AttritionRisk",
                          color_discrete_map=color_map, hover_data=["Name", "Department", "JobRole"],
                          template="plotly_dark", opacity=0.75)
        fig3.update_layout(paper_bgcolor="#161b22", plot_bgcolor="#0d1117", font_color="#c9d1d9",
                           margin=dict(l=10, r=10, t=10, b=10))
        st.plotly_chart(fig3, use_container_width=True)

    with c4:
        st.markdown('<p class="section-header">Top Feature Importances</p>', unsafe_allow_html=True)
        fi_df = feat_importances.head(10)
        fig4 = px.bar(fi_df, x="Importance", y="Feature", orientation="h",
                      template="plotly_dark", color="Importance", color_continuous_scale="Blues")
        fig4.update_layout(paper_bgcolor="#161b22", plot_bgcolor="#0d1117", font_color="#c9d1d9",
                           showlegend=False, margin=dict(l=10, r=10, t=10, b=10),
                           yaxis=dict(autorange="reversed"))
        st.plotly_chart(fig4, use_container_width=True)

    st.markdown('<p class="section-header">Avg Attrition Score — Department × Years at Company</p>', unsafe_allow_html=True)
    df_heat = df.copy()
    df_heat["TenureBucket"] = pd.cut(df_heat["YearsAtCompany"], bins=[0,2,5,10,20,40],
                                     labels=["<2","2-5","5-10","10-20","20+"])
    heat = df_heat.groupby(["Department","TenureBucket"], observed=True)["AttritionScore"].mean().reset_index()
    heat_pivot = heat.pivot(index="Department", columns="TenureBucket", values="AttritionScore")
    if not heat_pivot.empty:
        fig5 = px.imshow(heat_pivot, color_continuous_scale="RdYlGn_r",
                         template="plotly_dark", aspect="auto", text_auto=".2f")
        fig5.update_layout(paper_bgcolor="#161b22", plot_bgcolor="#0d1117", font_color="#c9d1d9",
                           margin=dict(l=10, r=10, t=10, b=10))
        st.plotly_chart(fig5, use_container_width=True)
    else:
        st.info("Not enough data to display tenure heatmap for current filters.")

with tab2:
    st.markdown('<p class="section-header">Employee Attrition Risk Register</p>', unsafe_allow_html=True)
    display_df = (
        df[["EmployeeID","Name","Department","JobRole","Salary",
            "YearsAtCompany","AbsenceDays","AttritionScore","AttritionRisk"]]
        .sort_values("AttritionScore", ascending=False)
        .reset_index(drop=True)
    )
    display_df.index += 1

    def color_risk(val):
        return {"High":"color: #f85149; font-weight:700","Medium":"color: #e3b341; font-weight:600","Low":"color: #3fb950"}.get(val,"")

    def color_score(val):
        if val >= 0.7: return "background-color: #f8514922"
        elif val >= 0.4: return "background-color: #e3b34122"
        return "background-color: #3fb95022"

    styled = (
        display_df.style
        .map(color_risk, subset=["AttritionRisk"])
        .map(color_score, subset=["AttritionScore"])
        .format({"AttritionScore": "{:.3f}", "Salary": "${:,.0f}"})
    )
    st.dataframe(styled, use_container_width=True, height=500)
    csv = display_df.to_csv(index=False)
    st.download_button("⬇ Download Risk Report (CSV)", csv, "attrition_risk_report.csv", "text/csv")

with tab3:
    st.markdown('<p class="section-header">NLP Sentiment Analysis on Employee Feedback</p>', unsafe_allow_html=True)
    sentiment_df = analyze_sentiment(df_raw)
    dept_morale  = get_department_morale(sentiment_df)
    c1, c2 = st.columns(2)

    with c1:
        st.markdown('<p class="section-header">Department Morale Scores</p>', unsafe_allow_html=True)
        fig_m = px.bar(dept_morale, x="Department", y="AvgSentiment", color="MoraleLabel",
                       color_discrete_map={"Positive":"#3fb950","Neutral":"#e3b341","Negative":"#f85149"},
                       template="plotly_dark")
        fig_m.update_layout(paper_bgcolor="#161b22", plot_bgcolor="#0d1117", font_color="#c9d1d9",
                            margin=dict(l=10, r=10, t=10, b=10))
        st.plotly_chart(fig_m, use_container_width=True)
        flagged = dept_morale[dept_morale["MoraleLabel"] == "Negative"]
        if not flagged.empty:
            st.warning(f"⚠️ **HR Intervention Recommended:** {', '.join(flagged['Department'].tolist())}")

    with c2:
        st.markdown('<p class="section-header">Sentiment Distribution</p>', unsafe_allow_html=True)
        sent_counts = sentiment_df["SentimentLabel"].value_counts().reset_index()
        sent_counts.columns = ["Sentiment", "Count"]
        fig_pie = px.pie(sent_counts, names="Sentiment", values="Count", color="Sentiment",
                         color_discrete_map={"Positive":"#3fb950","Neutral":"#e3b341","Negative":"#f85149"},
                         template="plotly_dark", hole=0.45)
        fig_pie.update_layout(paper_bgcolor="#161b22", font_color="#c9d1d9", margin=dict(l=10,r=10,t=10,b=10))
        st.plotly_chart(fig_pie, use_container_width=True)

    st.markdown("---")
    st.markdown('<p class="section-header">Sample Feedback & Sentiment Scores</p>', unsafe_allow_html=True)
    sample = sentiment_df[["Name","Department","FeedbackText","SentimentScore","SentimentLabel"]].head(15)
    def color_sent(val):
        return {"Positive":"color:#3fb950","Neutral":"color:#e3b341","Negative":"color:#f85149"}.get(val,"")
    st.dataframe(
        sample.style.map(color_sent, subset=["SentimentLabel"]).format({"SentimentScore":"{:.3f}"}),
        use_container_width=True,
    )

with tab4:
    st.markdown('<p class="section-header">Natural Language HR Query Interface</p>', unsafe_allow_html=True)
    st.markdown("<p style='color:#8b949e; font-size:0.9rem;'>Ask any HR question in plain English. The AI will analyze employee data and respond with insights.</p>", unsafe_allow_html=True)

    if "hr_query" not in st.session_state:
        st.session_state["hr_query"] = ""

    st.markdown("**💡 Try asking:**")
    suggestions = [
        "Who is at high attrition risk?",
        "Which department has the lowest morale?",
        "What drives employee attrition?",
        "Summarize Engineering team risks",
        "Who has been absent the most?",
    ]
    cols = st.columns(len(suggestions))
    for i, sug in enumerate(suggestions):
        if cols[i].button(sug, key=f"sug_{i}"):
            st.session_state["hr_query"] = sug
            st.rerun()

    user_query = st.text_input(
        "Your question:",
        value=st.session_state.get("hr_query", ""),
        placeholder="e.g. Who is at high attrition risk this month?",
        key="query_input",
    )
    openai_key = st.text_input(
        "OpenAI API Key (optional — uses rule-based fallback if not provided):",
        type="password", placeholder="sk-...",
    )
    if st.button("🔍 Ask HR AI", key="ask_btn"):
        if user_query.strip():
            with st.spinner("Analyzing employee data..."):
                response = query_hr_ai(user_query, df_raw, openai_key or None)
            st.markdown(
                f'<div class="ai-response-box">🤖 <strong>HR AI:</strong><br><br>{response}</div>',
                unsafe_allow_html=True,
            )
        else:
            st.warning("Please enter a question.")
