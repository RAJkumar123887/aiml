#!/bin/bash
# Run this once after installing requirements to download TextBlob corpora
python -m textblob.download_corpora
