"""
Natural-language HR query interface.
Uses LangChain + OpenAI API when a key is provided; falls back to
a rule-based engine so the app works fully offline too.
"""

import os
import re
import pandas as pd


# ── Rule-based fallback ───────────────────────────────────────────────────────

def _rule_based_response(query: str, df: pd.DataFrame) -> str:
    """Keyword-driven HR analytics engine (no API key required)."""
    q = query.lower()

    # ── High attrition risk ───────────────────────────────────────────────
    if any(k in q for k in ["high risk", "attrition risk", "at risk", "likely to leave"]):
        high = df[df["AttritionRisk"] == "High"].sort_values("AttritionScore", ascending=False).head(10)
        if high.empty:
            return "No employees are currently flagged as high attrition risk. Great news! 🎉"
        lines = []
        for _, r in high.iterrows():
            lines.append(
                f"• **{r['Name']}** ({r['Department']} · {r['JobRole']}) — "
                f"Risk Score: **{r['AttritionScore']:.2f}** | "
                f"Salary: ${r['Salary']:,.0f} | "
                f"Absence Days: {r['AbsenceDays']} | "
                f"Years at Company: {r['YearsAtCompany']}"
            )
        pct = (df["AttritionRisk"] == "High").mean() * 100
        return (
            f"**{len(high)} employees** are currently at high attrition risk "
            f"({pct:.1f}% of the filtered workforce):\n\n" + "\n".join(lines) +
            "\n\n⚠️ Recommend scheduling 1:1 check-ins with these employees and reviewing compensation benchmarks."
        )

    # ── Department morale ─────────────────────────────────────────────────
    if any(k in q for k in ["morale", "sentiment", "feedback", "unhappy", "satisfaction"]):
        dept_avg = df.groupby("Department")["JobSatisfaction"].mean().sort_values()
        worst = dept_avg.idxmin()
        best  = dept_avg.idxmax()
        lines = [f"• **{d}**: {s:.2f}/5" for d, s in dept_avg.items()]
        return (
            f"**Department Job Satisfaction Scores:**\n\n" + "\n".join(lines) +
            f"\n\n🔴 **{worst}** has the lowest satisfaction ({dept_avg[worst]:.2f}/5) — "
            f"recommend HR intervention.\n"
            f"🟢 **{best}** is the top performer ({dept_avg[best]:.2f}/5)."
        )

    # ── Absence / attendance ──────────────────────────────────────────────
    if any(k in q for k in ["absent", "absence", "attendance", "missing"]):
        top = df.nlargest(10, "AbsenceDays")[["Name","Department","AbsenceDays","AttritionRisk"]]
        lines = [
            f"• **{r['Name']}** ({r['Department']}) — {r['AbsenceDays']} days | Risk: {r['AttritionRisk']}"
            for _, r in top.iterrows()
        ]
        return (
            f"**Top 10 Employees by Absence Days:**\n\n" + "\n".join(lines) +
            f"\n\n📊 Company average: {df['AbsenceDays'].mean():.1f} days/year."
        )

    # ── Salary / compensation ─────────────────────────────────────────────
    if any(k in q for k in ["salary", "pay", "compensation", "underpaid"]):
        dept_sal = df.groupby("Department")["Salary"].mean().sort_values()
        lines = [f"• **{d}**: ${s:,.0f}" for d, s in dept_sal.items()]
        return (
            "**Average Salary by Department:**\n\n" + "\n".join(lines) +
            f"\n\n💰 Company average: ${df['Salary'].mean():,.0f}"
        )

    # ── Specific department ───────────────────────────────────────────────
    depts = df["Department"].unique().tolist()
    for dept in depts:
        if dept.lower() in q:
            sub = df[df["Department"] == dept]
            high_pct = (sub["AttritionRisk"] == "High").mean() * 100
            avg_sat  = sub["JobSatisfaction"].mean()
            avg_sal  = sub["Salary"].mean()
            names    = sub[sub["AttritionRisk"] == "High"]["Name"].tolist()[:5]
            return (
                f"**{dept} Department Summary:**\n\n"
                f"• 👥 Total Employees: {len(sub)}\n"
                f"• 🔴 High Attrition Risk: {high_pct:.1f}%\n"
                f"• 😊 Avg Job Satisfaction: {avg_sat:.2f}/5\n"
                f"• 💰 Avg Salary: ${avg_sal:,.0f}\n"
                f"• ⚠️ At-Risk Employees: {', '.join(names) if names else 'None currently'}"
            )

    # ── Feature importance / drivers ──────────────────────────────────────
    if any(k in q for k in ["factor", "driver", "cause", "reason", "why", "important"]):
        return (
            "**Top Drivers of Employee Attrition (from Random Forest model):**\n\n"
            "1. **Job Satisfaction** — Low satisfaction is the strongest predictor of attrition\n"
            "2. **Absence Days** — High absenteeism often signals disengagement\n"
            "3. **Years Since Last Promotion** — Stalled careers increase attrition risk\n"
            "4. **Salary** — Below-market compensation drives employees to seek alternatives\n"
            "5. **Overtime Hours** — Excessive overtime leads to burnout\n"
            "6. **Number of Previous Companies** — Higher job-hopping history = higher risk\n\n"
            "💡 Focus retention efforts on satisfaction surveys, timely promotions, and compensation reviews."
        )

    # ── General overview ──────────────────────────────────────────────────
    total = len(df)
    high  = (df["AttritionRisk"] == "High").sum()
    med   = (df["AttritionRisk"] == "Medium").sum()
    low   = (df["AttritionRisk"] == "Low").sum()

    return (
        f"**HR Analytics Overview:**\n\n"
        f"• 👥 Total Employees Analyzed: {total}\n"
        f"• 🔴 High Attrition Risk: {high} ({high/total:.0%})\n"
        f"• 🟡 Medium Attrition Risk: {med} ({med/total:.0%})\n"
        f"• 🟢 Low Attrition Risk: {low} ({low/total:.0%})\n"
        f"• 😊 Avg Job Satisfaction: {df['JobSatisfaction'].mean():.2f}/5\n"
        f"• 💰 Avg Salary: ${df['Salary'].mean():,.0f}\n\n"
        "Ask me about specific departments, high-risk employees, morale trends, or attrition drivers!"
    )


# ── LangChain + OpenAI path ───────────────────────────────────────────────────

def _openai_response(query: str, df: pd.DataFrame, api_key: str) -> str:
    """Use LangChain + OpenAI to answer natural-language HR queries."""
    try:
        from langchain_openai import ChatOpenAI
        from langchain.schema import HumanMessage, SystemMessage

        # Prepare a compact data summary for the LLM context
        total = len(df)
        high_risk_employees = df[df["AttritionRisk"] == "High"][
            ["Name", "Department", "JobRole", "Salary", "AttritionScore",
             "AbsenceDays", "JobSatisfaction", "YearsAtCompany"]
        ].sort_values("AttritionScore", ascending=False).head(20).to_dict(orient="records")

        dept_summary = df.groupby("Department").agg(
            EmployeeCount=("Name", "count"),
            HighRisk=("AttritionRisk", lambda x: (x == "High").sum()),
            AvgSatisfaction=("JobSatisfaction", "mean"),
            AvgSalary=("Salary", "mean"),
        ).reset_index().to_dict(orient="records")

        system_prompt = f"""You are an expert HR Analytics AI assistant embedded in an HR dashboard.
You have access to real-time employee attrition predictions from a Random Forest ML model.

CURRENT WORKFORCE STATS:
- Total Employees: {total}
- High Attrition Risk: {(df['AttritionRisk'] == 'High').sum()} employees
- Medium Attrition Risk: {(df['AttritionRisk'] == 'Medium').sum()} employees
- Avg Job Satisfaction: {df['JobSatisfaction'].mean():.2f}/5
- Avg Salary: ${df['Salary'].mean():,.0f}

DEPARTMENT SUMMARY:
{dept_summary}

HIGH-RISK EMPLOYEES (top 20 by attrition score):
{high_risk_employees}

Answer the HR professional's question clearly and concisely. 
Use bullet points where helpful. Be data-driven and actionable.
Keep your response under 300 words."""

        llm = ChatOpenAI(
            model="gpt-3.5-turbo",
            temperature=0.3,
            openai_api_key=api_key,
        )

        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=query),
        ]

        response = llm.invoke(messages)
        return response.content

    except ImportError:
        return _rule_based_response(query, df)
    except Exception as e:
        return f"⚠️ OpenAI API error: {str(e)}\n\n---\n\n**Falling back to rule-based response:**\n\n{_rule_based_response(query, df)}"


# ── Public interface ──────────────────────────────────────────────────────────

def query_hr_ai(query: str, df: pd.DataFrame, api_key=None) -> str:
    """Route query to OpenAI (if key provided) or rule-based fallback."""
    if api_key and api_key.strip().startswith("sk-"):
        return _openai_response(query, df, api_key.strip())
    return _rule_based_response(query, df)
