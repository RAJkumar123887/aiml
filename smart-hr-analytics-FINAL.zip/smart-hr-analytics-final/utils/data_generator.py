"""
Synthetic HR data generator.
Simulates realistic payroll + attendance + employee records.
"""

import numpy as np
import pandas as pd
from faker import Faker

fake = Faker()

DEPARTMENTS = ["Engineering", "Sales", "HR", "Finance", "Marketing", "Operations", "Product"]
JOB_ROLES = {
    "Engineering": ["Software Engineer", "Senior Engineer", "Tech Lead", "DevOps Engineer"],
    "Sales": ["Sales Rep", "Account Manager", "Sales Lead", "BDR"],
    "HR": ["HR Generalist", "Recruiter", "HR Manager", "L&D Specialist"],
    "Finance": ["Financial Analyst", "Accountant", "Finance Manager", "Controller"],
    "Marketing": ["Marketing Analyst", "Content Writer", "SEO Specialist", "Brand Manager"],
    "Operations": ["Operations Analyst", "Ops Manager", "Supply Chain Analyst", "Coordinator"],
    "Product": ["Product Manager", "Product Analyst", "UX Designer", "Scrum Master"],
}


def generate_hr_data(n: int = 500, seed: int = 42) -> pd.DataFrame:
    np.random.seed(seed)
    Faker.seed(seed)

    records = []
    for i in range(1, n + 1):
        dept = np.random.choice(DEPARTMENTS)
        role = np.random.choice(JOB_ROLES[dept])
        years = max(0, int(np.random.exponential(4)))
        age = np.random.randint(22, 58)
        salary_base = {"Engineering": 95000, "Sales": 65000, "HR": 60000,
                       "Finance": 80000, "Marketing": 70000,
                       "Operations": 62000, "Product": 90000}[dept]
        salary = int(np.random.normal(salary_base + years * 2000, 12000))
        salary = max(40000, salary)

        absence_days = max(0, int(np.random.poisson(5 if dept != "Sales" else 8)))
        overtime_hrs = max(0, int(np.random.normal(10, 8)))
        perf_rating = np.random.choice([1, 2, 3, 4, 5], p=[0.05, 0.15, 0.40, 0.30, 0.10])
        satisfaction = np.random.randint(1, 6)
        last_promotion = max(0, int(np.random.exponential(2.5)))
        dist_from_home = np.random.randint(1, 50)
        num_companies = np.random.randint(1, 8)
        training_hrs = max(0, int(np.random.normal(20, 10)))

        records.append({
            "EmployeeID":       f"EMP{i:04d}",
            "Name":             fake.name(),
            "Age":              age,
            "Department":       dept,
            "JobRole":          role,
            "Salary":           salary,
            "YearsAtCompany":   years,
            "AbsenceDays":      absence_days,
            "OvertimeHours":    overtime_hrs,
            "PerformanceRating": perf_rating,
            "JobSatisfaction":  satisfaction,
            "YearsSinceLastPromotion": last_promotion,
            "DistanceFromHome": dist_from_home,
            "NumCompaniesPrevious": num_companies,
            "TrainingHoursLastYear": training_hrs,
        })

    df = pd.DataFrame(records)
    return df
