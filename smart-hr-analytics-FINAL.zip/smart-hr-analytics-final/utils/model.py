"""
Random Forest attrition model.
Trains, cross-validates, and returns feature importances.
"""

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
from sklearn.model_selection import cross_val_score


NUMERIC_FEATURES = [
    "Age", "Salary", "YearsAtCompany", "AbsenceDays",
    "OvertimeHours", "PerformanceRating", "JobSatisfaction",
    "YearsSinceLastPromotion", "DistanceFromHome",
    "NumCompaniesPrevious", "TrainingHoursLastYear",
]
CATEGORICAL_FEATURES = ["Department", "JobRole"]


def load_or_train_model(X, y, preprocessor):
    """Train Random Forest pipeline and return model, CV score, feature importances."""

    pipeline = Pipeline([
        ("preprocessor", preprocessor),
        ("classifier", RandomForestClassifier(
            n_estimators=200,
            max_depth=8,
            min_samples_split=10,
            min_samples_leaf=4,
            class_weight="balanced",
            random_state=42,
            n_jobs=-1,
        )),
    ])

    # Cross-validation
    cv_scores = cross_val_score(pipeline, X, y, cv=5, scoring="accuracy", n_jobs=-1)
    cv_score = cv_scores.mean()

    # Fit final model on full data
    pipeline.fit(X, y)

    # Extract feature importances
    clf = pipeline.named_steps["classifier"]
    prep = pipeline.named_steps["preprocessor"]

    cat_features_out = (
        prep.named_transformers_["cat"]
        .named_steps["encoder"]
        .get_feature_names_out(CATEGORICAL_FEATURES)
        .tolist()
    )
    all_features = NUMERIC_FEATURES + cat_features_out
    importances = clf.feature_importances_

    feat_df = (
        pd.DataFrame({"Feature": all_features, "Importance": importances})
        .sort_values("Importance", ascending=False)
        .reset_index(drop=True)
    )

    return pipeline, cv_score, feat_df


def predict_attrition(df: pd.DataFrame, model, preprocessor) -> pd.DataFrame:
    """Append AttritionScore and AttritionRisk columns to the DataFrame."""
    df = df.copy()
    NUMERIC_FEATURES_ = [
        "Age", "Salary", "YearsAtCompany", "AbsenceDays",
        "OvertimeHours", "PerformanceRating", "JobSatisfaction",
        "YearsSinceLastPromotion", "DistanceFromHome",
        "NumCompaniesPrevious", "TrainingHoursLastYear",
    ]
    CATEGORICAL_FEATURES_ = ["Department", "JobRole"]

    X_infer = df[NUMERIC_FEATURES_ + CATEGORICAL_FEATURES_]
    proba = model.predict_proba(X_infer)[:, 1]

    df["AttritionScore"] = proba

    def risk_label(p):
        if p >= 0.65:   return "High"
        elif p >= 0.40: return "Medium"
        return "Low"

    df["AttritionRisk"] = df["AttritionScore"].apply(risk_label)
    return df
