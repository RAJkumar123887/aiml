"""
Pandas preprocessing pipeline for HR data.
Cleans raw payroll exports and engineers features for the attrition model.
"""

import pandas as pd
import numpy as np
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn import __version__ as sklearn_version
from packaging.version import Version


NUMERIC_FEATURES = [
    "Age", "Salary", "YearsAtCompany", "AbsenceDays",
    "OvertimeHours", "PerformanceRating", "JobSatisfaction",
    "YearsSinceLastPromotion", "DistanceFromHome",
    "NumCompaniesPrevious", "TrainingHoursLastYear",
]

CATEGORICAL_FEATURES = ["Department", "JobRole"]


def preprocess_data(df: pd.DataFrame):
    """
    Clean raw HR DataFrame and return feature matrix X, labels y, and fitted preprocessor.

    Attrition label is synthetically derived from risk factors so the project
    runs fully offline without needing a real labelled dataset.
    """
    df = df.copy()

    # ── Clean numeric columns ──────────────────────────────────────────────
    for col in NUMERIC_FEATURES:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    df[NUMERIC_FEATURES] = df[NUMERIC_FEATURES].fillna(df[NUMERIC_FEATURES].median())

    # ── Synthetic attrition label based on domain logic ───────────────────
    risk_score = (
        (df["AbsenceDays"] / df["AbsenceDays"].max()) * 0.20 +
        (1 - df["JobSatisfaction"] / 5) * 0.25 +
        (1 - df["PerformanceRating"] / 5) * 0.15 +
        (df["YearsSinceLastPromotion"] / df["YearsSinceLastPromotion"].clip(upper=10).max()) * 0.15 +
        (df["NumCompaniesPrevious"] / df["NumCompaniesPrevious"].max()) * 0.10 +
        (df["OvertimeHours"] / df["OvertimeHours"].max()) * 0.10 +
        (1 - df["Salary"] / df["Salary"].max()) * 0.05
    )

    noise = np.random.default_rng(42).normal(0, 0.05, len(df))
    risk_score = (risk_score + noise).clip(0, 1)

    threshold = risk_score.quantile(0.30)
    y = (risk_score > threshold).astype(int)

    # ── Build sklearn preprocessor (compatible with sklearn >= 1.0) ───────
    # sparse_output was added in sklearn 1.2; older versions use sparse=
    try:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
    except TypeError:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse=False)

    numeric_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])

    categorical_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("encoder", encoder),
    ])

    preprocessor = ColumnTransformer([
        ("num", numeric_pipeline, NUMERIC_FEATURES),
        ("cat", categorical_pipeline, CATEGORICAL_FEATURES),
    ])

    X = df[NUMERIC_FEATURES + CATEGORICAL_FEATURES]

    return X, y, preprocessor
