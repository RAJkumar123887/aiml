"""
NLP Sentiment Analysis on employee feedback forms.
Uses TextBlob for polarity scoring (no API key required).
Identifies department morale trends and flags teams needing HR intervention.
"""

import numpy as np
import pandas as pd
from textblob import TextBlob
from faker import Faker

fake = Faker()

# ── Synthetic feedback templates ─────────────────────────────────────────────
POSITIVE_FEEDBACK = [
    "I love working here, the team is very supportive and management listens to us.",
    "Great work-life balance and excellent growth opportunities.",
    "My manager is fantastic. I feel valued and recognized for my contributions.",
    "The culture here is amazing. Collaborative, inclusive, and innovative.",
    "I am very satisfied with my role. The projects are challenging and rewarding.",
    "Excellent benefits and flexible working arrangements. Highly recommend this company.",
    "I feel heard and appreciated. The leadership team is transparent and approachable.",
    "Strong learning and development programs. I've grown a lot in the past year.",
    "The company genuinely cares about employee wellbeing and mental health.",
    "I look forward to coming to work every day. This is a great place to build a career.",
]

NEUTRAL_FEEDBACK = [
    "Work is okay. Some processes could be improved but overall things are fine.",
    "The job is stable and the pay is average for the industry.",
    "It's a decent place to work. Nothing exceptional but nothing bad either.",
    "Management is okay. Communication could be better at times.",
    "The workload is manageable most days. Sometimes deadlines are tight.",
    "I have mixed feelings about my role. Some aspects I enjoy, others not so much.",
    "The company has potential but needs to improve in several areas.",
    "Decent onboarding experience. Some things could be clearer from the start.",
    "Pay is fair. Benefits are standard. Not much room for advancement though.",
    "I like my team but the overall company direction is unclear sometimes.",
]

NEGATIVE_FEEDBACK = [
    "I am extremely frustrated with the lack of recognition and career growth.",
    "Management micromanages everything. There is no trust or autonomy.",
    "The workload is unsustainable. I am constantly overworked and burned out.",
    "Poor communication from leadership. We are always the last to know things.",
    "I feel undervalued and underpaid compared to industry standards.",
    "There is a toxic culture in my team. HR does not take complaints seriously.",
    "No work-life balance whatsoever. I am expected to be available 24/7.",
    "The company made a lot of promises during hiring that were never kept.",
    "I am actively looking for other opportunities due to poor management.",
    "Morale is at an all-time low. Multiple people have left in the past month.",
]


def _generate_feedback(dept: str, sentiment_bias: float) -> str:
    """Generate a synthetic feedback sentence biased toward a sentiment."""
    r = np.random.random() + sentiment_bias * 0.3

    if r > 0.65:
        return np.random.choice(POSITIVE_FEEDBACK)
    elif r > 0.35:
        return np.random.choice(NEUTRAL_FEEDBACK)
    else:
        return np.random.choice(NEGATIVE_FEEDBACK)


# Department morale biases (simulating real-world variation)
DEPT_BIAS = {
    "Engineering": 0.2,
    "Product":     0.15,
    "HR":         -0.1,
    "Finance":     0.05,
    "Sales":      -0.2,
    "Marketing":   0.1,
    "Operations": -0.15,
}


def analyze_sentiment(df: pd.DataFrame) -> pd.DataFrame:
    """
    Generate synthetic feedback for each employee and compute sentiment scores.
    In production, replace feedback generation with real survey/form data.
    """
    np.random.seed(99)
    df = df.copy()

    feedbacks, scores, labels = [], [], []

    for _, row in df.iterrows():
        bias = DEPT_BIAS.get(row["Department"], 0.0)
        # Employees with low satisfaction get more negative feedback
        sat_bias = (row["JobSatisfaction"] - 3) * 0.15
        combined_bias = bias + sat_bias

        text = _generate_feedback(row["Department"], combined_bias)
        score = TextBlob(text).sentiment.polarity  # range: -1 to 1

        feedbacks.append(text)
        scores.append(score)

        if score > 0.1:
            labels.append("Positive")
        elif score < -0.1:
            labels.append("Negative")
        else:
            labels.append("Neutral")

    df["FeedbackText"]   = feedbacks
    df["SentimentScore"] = scores
    df["SentimentLabel"] = labels

    return df


def get_department_morale(sentiment_df: pd.DataFrame) -> pd.DataFrame:
    """Aggregate sentiment by department and flag teams needing HR intervention."""
    dept_morale = (
        sentiment_df.groupby("Department")["SentimentScore"]
        .mean()
        .reset_index()
        .rename(columns={"SentimentScore": "AvgSentiment"})
        .sort_values("AvgSentiment")
    )

    def morale_label(score):
        if score > 0.1:   return "Positive"
        elif score > -0.1: return "Neutral"
        return "Negative"

    dept_morale["MoraleLabel"] = dept_morale["AvgSentiment"].apply(morale_label)

    return dept_morale
